#include "lista.h"

Lista::Lista()
{

}
